import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class addBalanceUser extends mainMenu
{
   public static String plusBalance;
   public static int addingBalance;
   
   JLabel amountAdd = new JLabel("How much would you like to add?");
   JTextField amountAdding = new JTextField(10);
   
   JLabel pass = new JLabel("Please enter your password.");
   JPasswordField confirmPassword = new JPasswordField(10);
   
   JButton confirmAdd = new JButton("Confirm");
   
   JPanel reconPanel = new JPanel();
   
  addBalanceUser()
  {
      setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
      
       getContentPane().removeAll();
       setTitle("Add Balance");
       setSize(400,200);
       setLayout(new GridBagLayout());
       GridBagConstraints c = new GridBagConstraints();
       
       c.gridx = 0;
       c.gridy = 0;
       add(amountAdd,c);
       
       c.gridx = 1;
       c.gridy = 0;
       add(amountAdding,c);

       
       c.gridx = 0;
       c.gridy = 1;
       add(pass,c);
       
       c.gridx = 1;
       c.gridy = 1;
       add(confirmPassword,c);
       
       c.gridx = 1;
       c.gridy = 2;
       add(confirmAdd,c);
           

           
    confirmAdd.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                confirmBalance(e);
            }
            
        });    
        
      pack();
  }
  
  public void confirmBalance(ActionEvent e)
    {
        String passwordVeri = confirmPassword.getText();
        
        if (passwordVeri.equals(passwordRegister))
        {
            plusBalance = amountAdding.getText();
            addingBalance = Integer.parseInt(plusBalance);
        
            balance += addingBalance;
            
            labelString += "\nAdded Balance";;
            detailString += "\nYou added " +plusBalance+ " to your account";
            new carTrans().mainPanel.updateUI();
            
            dispose();
        }
        
        else
        {
            JOptionPane.showMessageDialog(null, "Incorrect Password","Error", JOptionPane.ERROR_MESSAGE); 
        }
            
        
    }
}
