import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class carButton extends mainMenu{
    JPanel panel21 = new JPanel();
    JPanel panel22 = new JPanel();
    JPanel rentingPanel = new JPanel();
    public carButton(){
        

        rentingPanel.setLayout(new BorderLayout());
        rentingPanel.setBorder(BorderFactory.createEmptyBorder(20,0,0,0));
        
        centerPanel.add(rentingPanel);
        JPanel carBrandsPanel = new JPanel();
        carBrandsPanel.setLayout(new GridLayout(1,0,10,0));
        
        //panel1.setPreferredSize(new Dimension(740,100));
        rentingPanel.add(carBrandsPanel, BorderLayout.NORTH);
        
        ImageIcon hondaIcon = new ImageIcon(this.getClass().getResource("\\Cars\\Honda.png"));
        ImageIcon hyundaiIcon = new ImageIcon(this.getClass().getResource("\\Cars\\Hyundai.png"));
        ImageIcon toyotaIcon = new ImageIcon(this.getClass().getResource("\\Cars\\Toyota.png"));
        ImageIcon fordIcon = new ImageIcon(this.getClass().getResource("\\Cars\\Ford.png"));
        ImageIcon mitsubishiIcon = new ImageIcon(this.getClass().getResource("Cars\\Mitsubishi.png"));
        //ImageIcon logoIcon = new ImageIcon("joke.png");
        
        Image image1 = hondaIcon.getImage();
        Image image2 = hyundaiIcon.getImage();
        Image image3 = toyotaIcon.getImage();
        Image image4 = fordIcon.getImage();
        Image image5 = mitsubishiIcon.getImage();
        //Image image6 = logoIcon.getImage();
        
        Image newimg1 = image1.getScaledInstance(65, 40,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(65, 40,  java.awt.Image.SCALE_SMOOTH);
        Image newimg3 = image3.getScaledInstance(65, 40,  java.awt.Image.SCALE_SMOOTH);
        Image newimg4 = image4.getScaledInstance(65, 40,  java.awt.Image.SCALE_SMOOTH);
        Image newimg5 = image5.getScaledInstance(65, 40,  java.awt.Image.SCALE_SMOOTH);
        //Image newimg6 = image6.getScaledInstance(85, 40,  java.awt.Image.SCALE_SMOOTH);
        
        hondaIcon = new ImageIcon(newimg1);
        hyundaiIcon = new ImageIcon(newimg2);
        toyotaIcon = new ImageIcon(newimg3);
        fordIcon = new ImageIcon(newimg4);
        mitsubishiIcon = new ImageIcon(newimg5);
        //logoIcon = new ImageIcon(newimg6);
        
        JButton honda = new JButton(hondaIcon);
        JButton hyundai = new JButton(hyundaiIcon);
        JButton toyota = new JButton(toyotaIcon);
        JButton ford = new JButton(fordIcon);
        JButton mitsubishi = new JButton(mitsubishiIcon);
        
        
        
        //JLabel logo = new JLabel(logoIcon);
        //JLabel logo1 = new JLabel(logoIcon);
        //carBrandsPanel.add(logo);
        carBrandsPanel.add(honda);
        carBrandsPanel.add(hyundai);
        carBrandsPanel.add(toyota);
        carBrandsPanel.add(ford);
        carBrandsPanel.add(mitsubishi);
    
        
        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(2,1));
        rentingPanel.add(panel2,BorderLayout.CENTER);
        
        
        JPanel panel3 = new JPanel();
        panel3.setLayout(new FlowLayout());
        rentingPanel.add(panel3, BorderLayout.SOUTH);
        
        JButton rent = new JButton("Rent!");
        panel3.add(rent);
        
        panel21.setLayout(new FlowLayout());
        panel21.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));
        panel22.setLayout(new FlowLayout());
        panel22.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));
        panel2.add(panel21);
        panel2.add(panel22);
        
        //panel21.add(logo1);
        
        carBrandsPanel.setBackground(Color.white);
        
        panel21.setBackground(Color.white);
        panel22.setBackground(Color.white);
        panel3.setBackground(Color.white);
        
        
        honda.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    hondashowInforActionPerformed(e);
            }
        });
        hyundai.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    hyundaishowInforActionPerformed(e);
            }
        });
        toyota.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    toyotashowInforActionPerformed(e);
            }
        });
        ford.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    fordshowInforActionPerformed(e);
            }
        });
        mitsubishi.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    mitsubishishowInforActionPerformed(e);
            }
        });
        rent.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    rentshowInforActionPerformed(e);
            }
        });
    }
    public void rentshowInforActionPerformed(ActionEvent e){
        if (rentedCar == 0)
        {
            carRent rentals = new carRent();
        }
        else
        {
            JOptionPane.showMessageDialog(null, "You have already rented a car. Please return first.", "One Car Rent Policy", JOptionPane.ERROR_MESSAGE);
        }
    }
    public void hondashowInforActionPerformed(ActionEvent e){
        panel21.removeAll();
        panel22.removeAll();
        
        ImageIcon honda1Icon = new ImageIcon(this.getClass().getResource("\\Cars\\hc1.png"));
        ImageIcon honda2Icon = new ImageIcon(this.getClass().getResource("\\Cars\\hc2.png"));
        
        Image image1 = honda1Icon.getImage();
        Image image2 = honda2Icon.getImage();
        
        Image newimg1 = image1.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        
        honda1Icon = new ImageIcon(newimg1);
        honda2Icon = new ImageIcon(newimg2);
        
        JLabel honda1 = new JLabel(honda1Icon);
        JLabel honda2 = new JLabel(honda2Icon);
        
        JLabel hc1 = new JLabel("<html>Car Code: <font color=red>H002</font>"
                               +"<br>Brand: Honda <br> Type: Minivan (2022 Honda <font color=red>Odyssey</font>)"
                               +"<br> Registration Number: 1380 - 00000821453"
                               +"<br>Plate Number: UBT 4651 <br> Seats: 7"
                               +"<br> Rent Price: Php 3800</html> ");
        JLabel hc2 = new JLabel("<html>Car Code: <font color=red>H001</font>"
                               +"<br>Brand: Honda <br> Type: Sedan (<font color=red>Brio</font>)" 
                               +"<br> Registration Number: 0401 - 00000228437" 
                               +"<br> Plate Number: DEB 2131 <br> Seats: 5 <br>"
                               +"Rent Price: Php 1300/day</html>");
        
        
        hc1.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        hc2.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        
        panel21.add(hc2);
        panel21.add(honda1);
        panel22.add(hc1);
        panel22.add(honda2);
        panel21.updateUI();
        panel22.updateUI();
    }
    public void hyundaishowInforActionPerformed(ActionEvent e){ 
        panel21.removeAll();
        panel22.removeAll();
        
        ImageIcon hyundai1Icon = new ImageIcon(this.getClass().getResource("\\Cars\\hyd1.png"));
        ImageIcon hyundai2Icon = new ImageIcon(this.getClass().getResource("\\Cars\\hyd2.png"));
        
        Image image1 = hyundai1Icon.getImage();
        Image image2 = hyundai2Icon.getImage();
        
        Image newimg1 = image1.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        
        hyundai1Icon = new ImageIcon(newimg1);
        hyundai2Icon = new ImageIcon(newimg2);
        
        JLabel hyundai1 = new JLabel(hyundai1Icon);
        JLabel hyundai2 = new JLabel(hyundai2Icon);
        
        JLabel hyd1 = new JLabel("<html>Car Code: <font color=red>HY001</font>"
                                +"<br>Brand: Hyundai <br> Type: Sedan (<font color=red>Accent</font> 2022)"
                                +"<br> Registration Number: 1301 - 00000216843 <br> Plate Number: CJA 9107"
                                +"<br> Seats: 5 <br> Rent Price: Php 1800/day</html>");
        JLabel hyd2 = new JLabel("<html>Car Code: <font color=red>HY002</font>"
                                +"<br>Brand: Hyundai <br> Type: Minivan (Hyundai <font color=red>Staria</font> 2022)"
                                +"<br> Registration Number: 1304 - 00000061827 <br> Plate Number: PAQ 3221 "
                                +"<br> Seats: 7 <br> Rent Price: Php 3400</html>");
        
        
        hyd1.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        hyd2.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
   
        
        panel21.add(hyd1);
        panel21.add(hyundai1);
        panel22.add(hyd2);
        panel22.add(hyundai2);
        panel21.updateUI();
        panel22.updateUI();
    }
    public void toyotashowInforActionPerformed(ActionEvent e){ 
        panel21.removeAll();
        panel22.removeAll();
        
        ImageIcon toyota1Icon = new ImageIcon(this.getClass().getResource("Cars\\tyt1.png"));
        ImageIcon toyota2Icon = new ImageIcon(this.getClass().getResource("Cars\\tyt2.png"));
        
        Image image1 = toyota1Icon.getImage();
        Image image2 = toyota2Icon.getImage();
        
        Image newimg1 = image1.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        
        toyota1Icon = new ImageIcon(newimg1);
        toyota2Icon = new ImageIcon(newimg2);
        
        JLabel toyota1 = new JLabel(toyota1Icon);
        JLabel toyota2 = new JLabel(toyota2Icon);
        
        JLabel tyt1 = new JLabel("<html>Car Code: <font color=red>T001</font>"
                                +"<br>      Brand: Toyota <br> Type: Sedan (<font color=red>Vios</font>)"
                                +"<br>      Registration Number: 0401 - 00000289252"
                                +"<br>      Plate Number: CAO 1023 <br> Seats: 5"
                                +"<br>      Rent Price: Php 1550/day</html>");
        JLabel tyt2 = new JLabel("<html>Car Code: <font color=red>T002</font>"
                                +"<br>      Brand: Toyota <br> Type: SUV (2022 <font color=red>4Runner</font>)"
                                +"<br>      Registration Number: 1336 - 00000739183 "
                                +"<br>      Plate Number: AUA 2241 <br> Seats: 7 <br> "
                                +"Rent      Price: Php 3550</html>");
        
        tyt1.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        tyt2.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        

        
        panel21.add(tyt1);
        panel21.add(toyota1);
        panel22.add(tyt2);
        panel22.add(toyota2);
        panel21.updateUI();
        panel22.updateUI();
    }
    public void fordshowInforActionPerformed(ActionEvent e){ 
        panel21.removeAll();
        panel22.removeAll();
        
        ImageIcon ford1Icon = new ImageIcon(this.getClass().getResource("\\Cars\\frd1.png"));
        ImageIcon ford2Icon = new ImageIcon(this.getClass().getResource("\\Cars\\frd2.png"));
        
        Image image1 = ford1Icon.getImage();
        Image image2 = ford2Icon.getImage();
        
        Image newimg1 = image1.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        
        ford1Icon = new ImageIcon(newimg1);
        ford2Icon = new ImageIcon(newimg2);
        
        JLabel ford1 = new JLabel(ford1Icon);
        JLabel ford2 = new JLabel(ford2Icon);
        
        JLabel frd1 = new JLabel("<html>Car Code: <font color=red>F002</font>"
                                +"<br>      Brand: Ford <br>Type: Minivan (2022 Ford <font color=red>TC Titanium</font>)"
                                +"<br>      Registration Number: 3001 - 00000562936<br> Plate Number: TTC 3814<br> Seats: 7"
                                +"<br>      Rent Price: Php 2900</html>");
        JLabel frd2 = new JLabel("<html>Car Code: <font color=red> F001</font>"
                                +"<br>      Brand: Ford <br> Type: Sedan (2019 Ford <font color=red>Fiesta</font>)"
                                +"<br>      Registration Number: 1501 - 00000153168 <br> Plate Number: CDB 6438<br> Seats: 5"
                                +"<br>      Rent Price: Php 1750/day</html>");
        
        frd1.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        frd2.setFont(new Font("Helvetica Neue", Font.BOLD, 15));

        
        panel21.add(frd2);
        panel21.add(ford1);
        panel22.add(frd1);
        panel22.add(ford2);
        panel21.updateUI();
        panel22.updateUI();
    }
    public void mitsubishishowInforActionPerformed(ActionEvent e){ 
        panel21.removeAll();
        panel22.removeAll();
        
        ImageIcon mitsubi1Icon = new ImageIcon(this.getClass().getResource("\\Cars\\mtsb1.png"));
        ImageIcon mitsubi2Icon = new ImageIcon(this.getClass().getResource("\\Cars\\mtsb2.png"));
        
        Image image1 = mitsubi1Icon.getImage();
        Image image2 = mitsubi2Icon.getImage();
        
        Image newimg1 = image1.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        Image newimg2 = image2.getScaledInstance(180, 100,  java.awt.Image.SCALE_SMOOTH);
        
        mitsubi1Icon = new ImageIcon(newimg1);
        mitsubi2Icon = new ImageIcon(newimg2);
        
        JLabel mitsubi1 = new JLabel(mitsubi1Icon);
        JLabel mitsubi2 = new JLabel(mitsubi2Icon);
        
        JLabel mtsb1 = new JLabel("<html>Car Code: <font color=red> M001</font>"
                                 +"<br>     Brand: Mitsubishi <br> Type: Sedan (2021 <font color=red>Mirage</font>)"
                                 +"<br>     Registration Number: 0401 - 00000228107 <br> Plate Number: UWL 8224"
                                 +"<br>     Seats: 5 <br> Rent Price: Php 1400/day<br></html>");
        JLabel mtsb2 = new JLabel("<html>   Car Code: <font color=red> M002</font>"
                                 +"<br>     Brand: Mistubishi <br> Type: Minivan (<font color=red>Delica</font> D:5)"
                                 +"<br>     Registration Number:  1303 - 00000961827 <br> Plate Number: JBU 738" 
                                 +"<br>     Seats: 7 <br> Rent Price: Php 3700</html>");
        
        mtsb1.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        mtsb2.setFont(new Font("Helvetica Neue", Font.BOLD, 15));
        
        
        panel21.add(mtsb1);
        panel21.add(mitsubi1);
        panel22.add(mtsb2);
        panel22.add(mitsubi2);
        panel21.updateUI();
        panel22.updateUI();
        
        
    }
    
}
    
