import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

class Car {
    private String brand, codeNum, model, regNo;
    private int rate;



    public Car(String newBrand, String newModel, String newRegNo, int newRate, String newCodeNum) {
        brand = newBrand;
        model = newModel;
        regNo = newRegNo;
        rate = newRate;
        codeNum = newCodeNum;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public String getRegNo() {
        return regNo;
    }

    public int getRate() {
        return rate;
    }
    
    public String getCodeNum() {
        return codeNum;
    }
    }

public class carRent extends carButton
{
    
    
    
    JPanel balanceTop = new JPanel(new GridBagLayout());
    JPanel main = new JPanel(new GridBagLayout());
    JPanel rentConfirmation = new JPanel(new GridBagLayout());
    JPanel paymentCenter = new JPanel(new GridBagLayout());
    
    JLabel balanceRent = new JLabel();
    JLabel title = new JLabel("<html><font size=4>Search for <font color=red>Car Details: </font></html>");
    JLabel brand = new JLabel("<html><font size=4>Brand: ");
    JLabel type = new JLabel("<html><font size=4>Type: ");
    JLabel plateNumber = new JLabel("<html><font size=4>Plate#: ");
    JLabel rentPrize = new JLabel("<html><font size=4>Price: ");
    JLabel rentDays = new JLabel("<html><font size=4><font color=red>Rent Days: ");
    JLabel totalPay = new JLabel("<html><font size=4>Amount: ");
    JLabel iniDeposit = new JLabel("<html><font size=4>Deposit: ");

    
    JTextField balanceTB = new JTextField();
    JTextField searchHere = new JTextField();
    JTextField brandInfo = new JTextField();
    JTextField typeTB = new JTextField();
    JTextField plateNumberInfo = new JTextField();
    JTextField rentPrizeInfo = new JTextField();
    JTextField rentDaysTB = new JTextField();
    JTextField totalPayTB = new JTextField();
    JTextField depositTB = new JTextField();
    
    
    JButton days = new JButton("Total");
    JButton rent = new JButton("Rent");
    JButton search = new JButton("Search");
    
    public carRent()
    {
        getContentPane().removeAll();
        ArrayList<Car> carlist = new ArrayList<Car>();
                            //BRAND         TYPE          PLATE NUMBER  RATE   CODE NUMBER
        carlist.add(new Car("Toyota",      "Vios",        "CAO 1023",   1550,   "T001"));
        carlist.add(new Car("Toyota",      "4Runner",     "AUA 2241",   3550,   "T002"));
        carlist.add(new Car("Mitshubishi", "Mirage",      "UWL 8224",   1400,   "M001"));
        carlist.add(new Car("Mitshubishi", "Delica",      "JBU 738",    3700,   "M002"));
        carlist.add(new Car("Ford",        "Fiesta",      "CDB 6438",   1750,   "F002"));
        carlist.add(new Car("Ford",        "TC Titanium", "TTC 3814",   2900,   "F001"));
        carlist.add(new Car("Honda",       "Brio",        "DEB 2131",   1300,   "H002"));
        carlist.add(new Car("Honda",       "Odyssey",     "UBT 4651",   3800,   "H001"));
        carlist.add(new Car("Hyundai",     "Accent",      "CJA 9107",   1800,   "HY001"));
        carlist.add(new Car("Hyundai",     "Staria",      "PAQ 3221",   3400,   "HY002"));
        
        
        setTitle("Car Rent Details");
        
        setFont(new Font("Helvetica Neue", Font.BOLD, 30));
        
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //setSize(500,400);
        setVisible(true);
    
        typeTB.setEditable(false);
        brandInfo.setEditable(false);
        plateNumberInfo.setEditable(false);
        rentPrizeInfo.setEditable(false);
        depositTB.setEditable(false);
        userBalanceTxt.setEditable(false);
        
        getContentPane().setLayout(new BorderLayout());
        GridBagConstraints gbcnt = new GridBagConstraints();
    
        gbcnt.fill = GridBagConstraints.HORIZONTAL;
        gbcnt.gridx = 1;
        gbcnt.gridy = 0;
        gbcnt.gridwidth = 3;
        //title.setBorder(BorderFactory.createEmptyBorder(0,15,0,15));
        main.add(title,gbcnt);
        

        //User's Balance - Label
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        balanceTop.add(userBalance,c);
        //User's Balance - TextField
        c.gridx = 1;
        c.gridy = 1;
        userBalance.setBorder(BorderFactory.createEmptyBorder(0,10,0,0));
        userBalanceTxt.setText(strBalance);
        balanceTop.add(userBalanceTxt,c);
        
        gbcnt.gridx = 0;
        gbcnt.gridy = 1;
        gbcnt.gridwidth = 4;
        main.add(searchHere,gbcnt);
        
        gbcnt.gridx = 4;
        gbcnt.gridy = 1;
        gbcnt.gridwidth = 1;
        search.setMargin(new Insets(0,0,0,0));
        main.add(search,gbcnt);
        
        gbcnt.gridx = 0;
        gbcnt.gridy = 2;
        main.add(brand,gbcnt);
        
        gbcnt.gridx = 1;
        gbcnt.gridy = 2;
        main.add(brandInfo,gbcnt);
        
        gbcnt.gridx = 0;
        gbcnt.gridy = 3;
        main.add(type,gbcnt);
        
        gbcnt.gridx = 1;
        gbcnt.gridy = 3;
        main.add(typeTB,gbcnt);
        
        gbcnt.gridx = 2;
        gbcnt.gridy = 2;
        gbcnt.gridwidth = 1;
        main.add(plateNumber,gbcnt); 
        
        gbcnt.gridx = 3;
        gbcnt.gridy = 2;
        gbcnt.gridwidth = 2;
        main.add(plateNumberInfo,gbcnt);
        
        gbcnt.gridx = 2;
        gbcnt.gridy = 3;
        gbcnt.gridwidth = 2;
        main.add(rentPrize,gbcnt); 
        
        gbcnt.gridx = 3;
        gbcnt.gridy = 3;
        main.add(rentPrizeInfo,gbcnt);
        
        gbcnt.gridx = 0;
        gbcnt.gridy = 5;
        gbcnt.gridwidth = 1;
        main.add(rentDays,gbcnt);
        
        gbcnt.gridx = 1;
        gbcnt.gridy = 5;
        gbcnt.gridwidth = 1;
        main.add(rentDaysTB,gbcnt);
        
        gbcnt.gridx = 1;
        gbcnt.gridy = 6;
        gbcnt.gridwidth = 1;
        main.add(days,gbcnt);
        
        gbcnt.gridx = 0;
        gbcnt.gridy = 4;
        gbcnt.gridwidth = 3;
        main.add(iniDeposit,gbcnt);
        
        gbcnt.gridx = 1;
        gbcnt.gridy = 4;
        gbcnt.gridwidth = 4;
        depositString = String.valueOf(depositLock);
        depositTB.setText(depositString);
        main.add(depositTB,gbcnt);
        
        //payment
        
        
        
        gbcnt.gridx = 2;
        gbcnt.gridy = 5;
        gbcnt.gridwidth = 1;
        main.add(totalPay,gbcnt);
        
        gbcnt.gridx = 3;
        gbcnt.gridy = 5;
        gbcnt.gridwidth = 2;
        totalPayTB.setEditable(false);
        main.add(totalPayTB,gbcnt);
        
        gbcnt.gridx = 2;
        gbcnt.gridy = 6;
        gbcnt.gridwidth = 3;
        main.add(rent,gbcnt); 
        
        main.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        rentConfirmation.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        paymentCenter.setBorder(BorderFactory.createEmptyBorder(150,10,10,10));
        

        add(main, BorderLayout.WEST);
        add(rentConfirmation, BorderLayout.SOUTH);
        add(paymentCenter, BorderLayout.CENTER);
        add(balanceTop, BorderLayout.NORTH);
        
        pack();
        search.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
            String a = searchHere.getText();
            for (Car s : carlist) {
            if (a.equalsIgnoreCase(s.getModel()) || a.equalsIgnoreCase(s.getCodeNum())) {
                brandInfo.setText(s.getBrand());
                typeTB.setText(s.getModel());
                plateNumberInfo.setText(s.getRegNo());
                rentPrizeInfo.setText(Integer.toString(s.getRate()));
                searching += 1;
            }
            else
            {
                //do nothing
            }
            }
            }
        
            
        });
        
        days.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                carAmount = Double.parseDouble(rentPrizeInfo.getText());
                daysCount = Double.parseDouble(rentDaysTB.getText());
            
                if (daysCount == 0 || searching == 0)
                {
                    JOptionPane.showMessageDialog(null, "You are missing some required information.", 
                                                  "Error!", JOptionPane.INFORMATION_MESSAGE);
                }
                
                else
                {
                    payThis = carAmount * daysCount;
                    daysString = String.valueOf(daysCount);
                    payString = String.valueOf(payThis);
                    totalPayTB.setText(payString);
                }

            }
            });
        
        rent.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                if (balance >= depositLock && daysCount != 0 && searching != 0 )
                {
                    balance -= depositLock;
                    JOptionPane.showMessageDialog(null, "The deposit has been deducted from your account.", 
                                                  "Rent Successful!", JOptionPane.INFORMATION_MESSAGE); 
                    labelString += "\nRented Car";
                    detailString += "\nYou rented " +brandInfo.getText() + " " +typeTB.getText()+ " amounting to " +payThis;
                    rentedCar += 1;
                    brandString = brandInfo.getText();
                    typeString = brandInfo.getText();
                    mainPanel.updateUI();
                    utilPanel.updateUI();
                    searching = 0;
                    dispose();

                }
                
                else if(daysCount == 0 || searching == 0)
                {
                    JOptionPane.showMessageDialog(null, "You are missing some required information.", 
                                                  "Error!", JOptionPane.INFORMATION_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Please top up credits from the Main Menu", 
                                                  "Rent Failed", JOptionPane.ERROR_MESSAGE);
                                                 
                }
            }
            });     
    }
}

