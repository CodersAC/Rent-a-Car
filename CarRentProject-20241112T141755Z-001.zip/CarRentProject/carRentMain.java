import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class carRentMain extends JFrame
{   
    //constraints for all
    public static GridBagConstraints c = new GridBagConstraints();
    
    
    //inside JFrame you will see:
    JPanel headerPanel  = new JPanel(new GridLayout(1,1,9,1));
    JPanel mainPanel    = new JPanel(new BorderLayout());
    
    
    //fillers
    JPanel topPanel     = new JPanel();
    JPanel leftPanel    = new JPanel();
    JPanel accountPanel = new JPanel(new GridBagLayout());
    JPanel rightPanel   = new JPanel();
    JPanel bottomPanel  = new JPanel();

        
        //CAR RENT LOGO:
        ImageIcon carRentIC = new ImageIcon("carRent.png");
        JLabel carRentIcon  = new JLabel(carRentIC);
        
        
        //EXTRA BUTTONS XD:
        JButton contactUs = new JButton("Contact Us");
        JButton aboutUs   = new JButton("About Us");
        JButton reviews   = new JButton("Reviews");
        JButton termsCon  = new JButton("Terms&Condition");
        JButton faq       = new JButton("FAQ");

        
        //FOR LOGGING IN:
        JLabel comeBack   = new JLabel("Already own an account?");  
            //login icon                                         
            ImageIcon loginIC = new ImageIcon("login.png");          
            JLabel loginIcon  = new JLabel(loginIC);
            //login button                               
            JButton signIn    = new JButton("Log In");    

        
        //FOR SIGNING UP:
        JLabel newHere = new JLabel("Are you new here?");
            //register icon
            ImageIcon registerIC = new ImageIcon("register.png");
            JLabel registerIcon  = new JLabel(registerIC);
            //register button
            JButton signUp       = new JButton("Sign Up");

        
        //END PROGRAM
        JButton exitsignUser = new JButton("Exit");

        
    carRentMain()
    {
        setSize(800,600);
        setLocationRelativeTo(null);
        //FRAME ATTRIBUTES
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
        
        
        //FRAME TITLE
        setTitle("Car Rent: Welcome!");
        
        //GRIDLAYOUT FOR HEADERPANEL
        //add extra buttons to headerPanel        
        headerPanel.add(carRentIcon);
        headerPanel.add(contactUs); 
        headerPanel.add(aboutUs);
        headerPanel.add(reviews);
        headerPanel.add(termsCon);
        headerPanel.add(faq);
        //display headerPanel
        headerPanel.setBorder(BorderFactory.createRaisedBevelBorder());
        add(headerPanel, BorderLayout.NORTH);
        
        
        //GRIDBAGCONSTRAINTS FOR ACCOUNTPANEL
        //ADD LOGIN SYSTEM FOR ACCOUNT PANEL -- COORDS
        
        //Old Account - Label
        c.gridwidth = 3;
        comeBack.setFont(new Font("Verdana", Font.PLAIN, 15));
        accountPanel.add(comeBack,c);
        //Log In - Icon
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        accountPanel.add(loginIcon,c);
        //Log In - Button
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 2;
        signIn.setMargin(new Insets(5, 40, 5, 40));
        accountPanel.add(signIn,c);
        
        //New Account - Label
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 4;
        newHere.setBorder(BorderFactory.createEmptyBorder(40,0,0,0));
        newHere.setFont(new Font("Verdana", Font.PLAIN, 15));
        accountPanel.add(newHere,c);
        //Register - Icon
        c.gridx = 0;
        c.gridy = 5;
        c.gridwidth = 1;
        accountPanel.add(registerIcon,c);
        //Register - Button
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 2;
        signUp.setMargin(new Insets(5, 40, 5, 40));
        accountPanel.add(signUp,c);
        
        //BORDERLAYOUT FOR MAINPANEL
        //add fillers and accountPanel for planned layout
            //for top
            topPanel.setBorder(BorderFactory.createEmptyBorder(100,0,0,0));
            mainPanel.add(topPanel, BorderLayout.NORTH);
            //for left
            leftPanel.setBorder(BorderFactory.createEmptyBorder(0,250,0,0));
            mainPanel.add(leftPanel, BorderLayout.WEST);
            //for middle ----- MAIN panel in mainPanel
            accountPanel.setBorder(BorderFactory.createEmptyBorder(70,0,70,0));
            accountPanel.setBackground(Color.white);
            mainPanel.add(accountPanel, BorderLayout.CENTER);
            //for right
            rightPanel.setBorder(BorderFactory.createEmptyBorder(0,250,0,0));
            mainPanel.add(rightPanel, BorderLayout.EAST);
            //for bottom
            bottomPanel.setBorder(BorderFactory.createEmptyBorder(100,0,0,0));
            mainPanel.add(bottomPanel, BorderLayout.SOUTH);
            
            
        //display mainPanel
        add(mainPanel, BorderLayout.CENTER);
        mainPanel.setBackground(Color.white);
        
        
        //ADDING ACTION LISTENERS
        //----------------------- for header buttons
        //------------------------------------------ sign up
        signUp.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                signingUp(e);
            }
        });
        //------------------------------------------ sign in
        signIn.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                signingIn(e);
            }
        });
        //------------------------------------------ contact us
        contactUs.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(null, "Kristene Faith M. Prin\nContact Number: 09686988596\n" 
                                                  +"Email Address: krstene.faith@gmail.com\n"
                                                 
                                                  +"\nKristene Faith M. Prin\nContact Number: 09686988596\n"
                                                  +"Email Address: krstene.faith@gmail.com\n"
                                                 
                                                  +"\nKristene Faith M. Prin\nNumber: 09686988596"
                                                  +"\nEmail Address: krstene.faith@gmail.com",
                                                   "Contact Us", JOptionPane.INFORMATION_MESSAGE); 
            }
        });
        //------------------------------------------ about us
        aboutUs.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(null, "The most flexible, reliable, and reasonable car rental agency."
                                                  +"\nStarted business in 2002. The value is good."
                                                  +"\n The cars are clean and well-maintained. "
                                                  +"\nA parent to the cars.", 
                                                   "About Us", JOptionPane.INFORMATION_MESSAGE); 
            }
        });
        //------------------------------------------ reviews
        reviews.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(null, "5S *****: 'Cars have never felt newer'"
                                                  +"\n5S *****: 'Best car rental I've ever visited.'"
                                                  +"\n3S ***: 'Just hating for no reason.'",
                                                   "Reviews", JOptionPane.INFORMATION_MESSAGE); 
            }
        });
        //------------------------------------------ terms&conditions
        termsCon.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(null, "Currently updating our Terms and Conditions!", "Reviews", JOptionPane.ERROR_MESSAGE); 
            }
        });
        //------------------------------------------ faq
        faq.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(null, "What if I break the car?"
                                                  +"\nSimple, pay for it.\n"
                                                  +"\nHow much should I deposit for rental?"
                                                  +"\nPhP 15,000\n"
                                                  +"\nWhat happens if I go overdue?"
                                                  +"\nPhP 2,000/day", 
                                                   "Reviews", JOptionPane.INFORMATION_MESSAGE); 
            }
        });
        //----------------------- for main buttons
        //---------------------------------------- sign in
        pack();
    }
    
    //ADDING ACTION EVENTS
    //-------------------- for main buttons
    //------------------------------------- sign up
    public void signingUp(ActionEvent e)
    {
        accountPanel.removeAll();
        accountPanel.add(new userRegister().accountPanel);
        mainPanel.updateUI();
    }
    //------------------------------------- sign in
    public void signingIn(ActionEvent e)
    {
        if(userRegister.usernameRegister == null && userRegister.passwordRegister == null)
        {
            JOptionPane.showMessageDialog(null, "Please register first.","Create an Account", JOptionPane.ERROR_MESSAGE);  
        }
        
        else
        {
            new userLogin().show();
        }
    }
    
    //DISPLAY WELCOME PAGE!
    public static void main(String[] args)
    {
        new carRentMain().show();
    }
    
    

}
