import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
public class carTrans extends mainMenu
{
    
    
    //panel to insert in mainMenu
    JPanel mainPanel = new JPanel();
    
    //for the details
    JPanel transLabel = new JPanel(new BorderLayout());
    JPanel transDetails = new JPanel(new BorderLayout());
    
    //transcation labels
    JLabel labelTrans = new JLabel("<html><font size = 5>Transactions");
    JLabel detailsTrans = new JLabel("<html><font size = 5>Details");
    
    
    
    JTextArea userTransactionLabel = new JTextArea(50,14);
    JTextArea userTransactionDetails = new JTextArea(50,40);
    
    
    public carTrans() 
    {   
        getContentPane().removeAll();
        //remove contents
        setTitle("Transactions");
        
        //set layout for main panel
        mainPanel.setLayout(new BorderLayout());
        
        
        userTransactionLabel.setEditable(false);
        userTransactionDetails.setEditable(false);
        //userTransactionLabel.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        
        //labels
        
        userTransactionLabel.setFont(new Font("Arial", Font.PLAIN,15));
        userTransactionLabel.append(labelString);

        
        //details
        userTransactionDetails.setFont(new Font("Arial", Font.PLAIN,15));
        userTransactionDetails.append(detailString);
        
        //set Borders
        labelTrans.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        detailsTrans.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        
        //add panels
        transLabel.add(labelTrans, BorderLayout.NORTH);
        transDetails.add(detailsTrans, BorderLayout.NORTH);
        
        
        transLabel.add(userTransactionLabel, BorderLayout.CENTER);
        transDetails.add(userTransactionDetails, BorderLayout.CENTER);

        //c.gridwidth = 10;
        //c.gridheight = 20;
        
        //c.gridx = 0;
        //c.gridy = 0;
        
        mainPanel.add(transLabel, BorderLayout.WEST);

        //c.gridx = 1;
        mainPanel.add(transDetails, BorderLayout.CENTER);
            
    }
}
