import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class mainMenu extends userRegister
{    
    //INITIATE REQUIRED VARIABLES
    public static int balance = 0;
    public static int rentedCar = 0;
    public static int searching = 0;
    public static String strBalance;
    
    public static String labelString = "";
    public static String detailString = "";
    
    public static double carAmount, payThis;
    public static double daysCount;
    public static double depositLock = 15000;
    public static String payString, daysString, depositString, brandString, typeString;
    
    //FOR MAIN PANEL
    JPanel menuPanel    = new JPanel();
    JPanel balancePanel = new JPanel();
    JPanel utilPanel    = new JPanel(new BorderLayout());
    JPanel centerPanel  = new JPanel(new BorderLayout());
    JPanel meBottomPanel = new JPanel();
    
    //INSERT THESE PANELS IN UTILPANEL
    JPanel userPanel     = new JPanel(new GridBagLayout());
    JPanel optionsPanel  = new JPanel(new GridLayout(0,1,10,10));
    JPanel utBottomPanel = new JPanel();
    
    //BACKGROUND FOR MAINMENU FRAME:
    ImageIcon userBG      = new ImageIcon("mainMenu.png");
    JLabel userBackground = new JLabel(userBG);

    
    //ICON FOR SIGNUSER FRAME:
        ImageIcon userIC   = new ImageIcon("userProfile.png");
        JLabel userIcon    = new JLabel(userIC);
        //user's name
        JLabel usernameTxt = new JLabel(nameRegister);

    
    //FOR USER BALANCE
    JLabel userBalance         = new JLabel("Balance: ");
    JTextField userBalanceTxt  = new JTextField(6);
    //for adding user balance
    JButton addBalance         = new JButton("+");
    JButton showBalance        = new JButton("Show Balance");
        

    //ALL OPTION BUTTONS
    JButton rentCarButton          = new JButton("Rent Car");
    JButton returnCarButton        = new JButton("Return Car");
    JButton viewTransactionsButton = new JButton("View Transactions");
    JButton logOutButton           = new JButton("Logout");
    

     
    mainMenu()
    {
        //FRAME TITLE
        setTitle("Car Rent: Main Menu");
        
        //REMOVING CONTENTS
        //headerPanel.removeAll();
        mainPanel.removeAll();
        
        //GRIDLAYOUT FOR UTILPANNEL
        //GridBagLayout for userPanel
        //User Icon - Label
        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 1;
        userPanel.add(userIcon,c);
        //User's Name - Label
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 2;
        userPanel.add(usernameTxt,c);
        //User's Balance - Label
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 1;
        userPanel.add(userBalance,c);
        userBalanceTxt.setEditable(false);
        //User's Balance - TextField
        c.gridx = 1;
        c.gridy = 1;
        userBalance.setBorder(BorderFactory.createEmptyBorder(0,10,0,0));
        userPanel.add(userBalanceTxt,c);
        //User Add Balance - Button
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 1;
        c.fill = GridBagConstraints.NONE;
        addBalance.setMargin(new Insets(0,5,0,5));
        userPanel.add(addBalance,c);
        
        
        //Show User's Balance - Button
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        showBalance.setMargin(new Insets(0,5,0,5));
        userPanel.add(showBalance,c);
        
        
        //insert this in optionsPanel
            optionsPanel.add(rentCarButton);
            optionsPanel.add(returnCarButton);
            optionsPanel.add(viewTransactionsButton);
            optionsPanel.add(logOutButton);
        
        //GRIDLAYOUT FOR MAINPANEL
            //set borders for components in utilPanel
            userPanel.setBorder(BorderFactory.createEmptyBorder(0,0,120,0));
            optionsPanel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
            utBottomPanel.setBorder(BorderFactory.createEmptyBorder(140,20,0,0));
            //set border for components in centerPanel
            balancePanel.setBorder(BorderFactory.createEmptyBorder(70,0,0,0));
            meBottomPanel.setBorder(BorderFactory.createEmptyBorder(10,0,0,0));
            utilPanel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
            //add this in utilPanel
            utilPanel.add(userPanel, BorderLayout.NORTH);
            utilPanel.add(optionsPanel, BorderLayout.CENTER);
            utilPanel.add(utBottomPanel, BorderLayout.SOUTH);
        
        //display utilPanel
        
        mainPanel.add(balancePanel, BorderLayout.WEST);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(utilPanel, BorderLayout.EAST);
        mainPanel.add(meBottomPanel, BorderLayout.SOUTH);
        
        centerPanel.add(userBackground);
        
        //ADDING ACTION LISTENERS
        //----------------------- show balance
         showBalance.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                showBalance(e);
            }
        });
        //----------------------- add balance
        addBalance.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                addBalance(e);
            }
        });
        //----------------------- rent a car
        rentCarButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                rentCar(e);
            }
        });
        
        returnCarButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                returnCar(e);
            }
        });
        
        viewTransactionsButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                viewingTransactions(e);
            }
        });
        
        logOutButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                loggingOut(e);
            }
        });

    }
    //ADDING ACTION EVENTS
    //-------------------- for showing balance
    public void showBalance(ActionEvent e)
    {
        strBalance = String.valueOf(balance);
        userBalanceTxt.setText(strBalance);              
    }
    
    //-------------------- for adding balance
    public void addBalance(ActionEvent e)
    {
        new addBalanceUser().show();             
    }
    //-------------------- for renting car
    public void rentCar(ActionEvent e)
    {
        centerPanel.removeAll(); 
        centerPanel.add(new carButton().rentingPanel);
        mainPanel.updateUI();
    }
    
    public void returnCar(ActionEvent e)
    {
        if (rentedCar == 1)
        {
            centerPanel.removeAll(); 
            centerPanel.add(new returnCar().mainPanel);
            mainPanel.updateUI();
        }
        else
        {
            JOptionPane.showMessageDialog(null, "You have not rented a car. Please rent first.", "One Car Rent Policy", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void viewingTransactions(ActionEvent e)
    {
        centerPanel.removeAll(); 
        centerPanel.add(new carTrans().mainPanel);
        mainPanel.updateUI();
    }
    
    public void loggingOut(ActionEvent e)
    {
        System.exit(0);
    }

}
