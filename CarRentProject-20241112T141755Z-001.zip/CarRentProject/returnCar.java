import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class returnCar extends mainMenu
{
    JButton b2 = new JButton("Confirm Days");
    JButton b3 = new JButton("Return Car");

    JLabel l1 = new JLabel("Initial Payment: ");
    JLabel l2 = new JLabel("Days Rented: ");
    JLabel l3 = new JLabel("Day Returned: ");
    JLabel l4 = new JLabel("Total Amount: ");
    
    JTextField t1 = new JTextField(10);
    JTextField t2 = new JTextField(10);
    JTextField t3 = new JTextField(10);
    JTextField t4 = new JTextField(10);
    
    JPanel mainPanel = new JPanel();
    returnCar()
    {
        mainPanel.setLayout(new GridBagLayout());
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 1;
        
        c.gridx = 0;
        c.gridy = 0;
        mainPanel.add(l1,c);
        
        c.gridx = 0;
        c.gridy = 1;
        mainPanel.add(l2,c);
        
        c.gridx = 0;
        c.gridy = 2;
        mainPanel.add(l3,c);
        
        c.gridx = 0;
        c.gridy = 3;
        mainPanel.add(l4,c);
        
        
        c.gridx = 1;
        c.gridy = 0;
        t1.setText(payString);
        t1.setEditable(false);
        mainPanel.add(t1,c);
        
        c.gridx = 1;
        c.gridy = 1;
        t2.setText(daysString);
        t2.setEditable(false);;
        mainPanel.add(t2,c);
        
        c.gridx = 1;
        c.gridy = 2;
        mainPanel.add(t3,c);
        
        c.gridx = 1;
        c.gridy = 3;
        t4.setText("");
        t4.setEditable(false);
        mainPanel.add(t4,c);
        
        c.gridx = 2;
        c.gridy = 2;
        b2.setMargin(new Insets(0,0,0,0));
        mainPanel.add(b2,c);
        
        c.gridx = 0;
        c.gridy = 4;
        c.gridwidth = 2;
        mainPanel.add(b3,c);
        
        mainPanel.setBackground(Color.white);
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(mainPanel, BorderLayout.CENTER);
        
        b2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                confirmDays(e);
            }
        });
        
        b3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                returnCar(e);
            }
        });
        
    }
    public void confirmDays(ActionEvent e){ 
        t4.setText(Double.toString(totalAmount()));
    }
    
    public double totalAmount(){
        double overdue = Double.parseDouble(t3.getText());
        double penalty;
        double rentamount = payThis;
        if (daysCount < overdue){
            penalty = (overdue - daysCount) * (carAmount + 2000);
        }
        else{
            penalty = 0;
        }
        double total = penalty + rentamount ;
        return total;
    }
    public void returnCar(ActionEvent e){

    if (totalAmount() < super.balance){
        super.balance -= totalAmount();
        JOptionPane.showMessageDialog(null, "We have returned your deposit. Please check your balance.", "Return Success!", JOptionPane.INFORMATION_MESSAGE);
        rentedCar -= 1;
        super.balance += depositLock;
        labelString += "\nReturned Car";
                    detailString += "\nYou returned " +brandString + " " +typeString+ " amounting to " +payThis;
        
        mainPanel.removeAll();            
        centerPanel.removeAll();
        mainPanel.updateUI();
    }
    else
    {
        JOptionPane.showMessageDialog(null, "Please top up credits from the Main Menu", 
                                                  "Return Failed", JOptionPane.ERROR_MESSAGE);
    }
    }
    
}