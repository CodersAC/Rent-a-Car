import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class userLogin extends userRegister
{
    //INITIATE REQUIRED VARIABLES
    public static String usernameLogin, 
                         passwordLogin;

    JPanel accountPanel = new JPanel();
    //BACKGROUND FOR REGISTER
    ImageIcon userBG = new ImageIcon("signIn.png");
    JLabel userBackground = new JLabel(userBG);

    //FOR USERNAME LOGIN
    JLabel usernameLabel = new JLabel("Username:");
    JTextField inpUsername = new JTextField(10);
    
    //FOR PASSWORD LOGIN
    JLabel passwordLabel = new JLabel("Password:");
    JPasswordField inpPassword = new JPasswordField(10);
    
    //FOR LOGIN CONFIRMATION 
    JButton loginButton = new JButton("Login");
        
    
    userLogin()
    {
        //FRAME TITLE

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //REMOVING CONTENTS

        accountPanel.setBackground(Color.white);
        accountPanel.setLayout(new GridBagLayout());
        //GRIDBAGCONSTRAINTS FOR ACCOUNTPANEL
        //for all constraints
        c.fill = GridBagConstraints.HORIZONTAL;
        
        //ADD LOGIN SYSTEM FOR ACCOUNT PANEL -- COORDS
        //Log In - Icon
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 3;
        accountPanel.add(loginIcon,c);
        
        //Username Log In - Label
        c.gridx = 0;
        c.gridy = 1;
        accountPanel.add(usernameLabel,c);
        usernameLabel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
        //Username Log In - Input
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;
        accountPanel.add(inpUsername,c);
        
        //Password Log In - Password
        c.gridx = 0;
        c.gridy = 2;
        accountPanel.add(passwordLabel,c);
        passwordLabel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
        //Password Log In - Input
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        accountPanel.add(inpPassword,c);
        
        
        //Login - Button
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 3;
        signUp.setMargin(new Insets(5, 40, 5, 40));
        accountPanel.add(loginButton,c);
        
        
        //ADDING ACTION LISTENERS
        //----------------------- log in
        loginButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                loginUser(e);
            }
        });
          
    }
    
    //ADDING ACTION EVENTS
    //-------------------- for log in authentication
    public void loginUser(ActionEvent e)
    {
        usernameLogin = inpUsername.getText();
        passwordLogin = inpPassword.getText();
          
          
        if(usernameLogin.equalsIgnoreCase(usernameRegister) && passwordLogin.equalsIgnoreCase(passwordRegister))
        {
            dispose();
            new mainMenu().show(); 
        }
          
        else
        {
            JOptionPane.showMessageDialog(null, "The credentials are invalid.");
        }
    }
}
