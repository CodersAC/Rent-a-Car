import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class userRegister extends carRentMain
{
    //INITIATE REQUIRED VARIABLES
    public static String usernameRegister, 
                         nameRegister, 
                         passwordRegister;
    
    JPanel accountPanel = new JPanel();
    //BACKGROUND FOR REGISTER IF NONE
    ImageIcon userBG      = new ImageIcon("signUp.png");
    JLabel userBackground = new JLabel(userBG);

    
    //FOR USERNAME REGISTER 
    JLabel usernameLabel        = new JLabel("Username:");
    JTextField inpUsername1     = new JTextField(10);
    
    //FOR PASSWORD REGISTER 
    JLabel passwordLabel        = new JLabel("Password:");
    JPasswordField inpPassword1 = new JPasswordField(10);
    
    //FOR USER'S NAME
    JLabel addRessing           = new JLabel("What should we call you?");
    JLabel nameLabel            = new JLabel("Name: ");
    JTextField inpName          = new JTextField(10);
    
    //FOR REGISTER INFORMATION
    JButton registerButton      = new JButton("Register");
    
    
    userRegister()
    {
        

        accountPanel.setLayout(new GridBagLayout());
        //GRIDBAGCONSTRAINTS FOR ACCOUNTPANEL
        //for all constraints
        c.fill = GridBagConstraints.HORIZONTAL;
        
        //ADD REGISTER SYSTEM FOR ACCOUNT PANEL -- COORDS
        //Register - Icon
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 3;
        accountPanel.add(registerIcon,c);
        
        //Username Register - Label
        c.gridx = 0;
        c.gridy = 1;
        accountPanel.add(usernameLabel,c);
        usernameLabel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
        //Username Register - Input
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;
        accountPanel.add(inpUsername1,c);
        
        //Password Register - Password
        c.gridx = 0;
        c.gridy = 2;
        accountPanel.add(passwordLabel,c);
        passwordLabel.setBorder(BorderFactory.createEmptyBorder(0,0,0,10));
        //Password Register - Input
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        accountPanel.add(inpPassword1,c);
        
        //User's Name Register - Label
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 3;
        addRessing.setBorder(BorderFactory.createEmptyBorder(15,0,0,0));
        addRessing.setFont(new Font("Verdana", Font.PLAIN, 15));
        accountPanel.add(addRessing,c);
        
        //User's Name Register - Input
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 3;
        accountPanel.add(inpName,c);
        
        //Register Confirmation - Button
        c.gridx = 1; 
        c.gridy = 5; 
        c.gridwidth = 3;
        registerButton.setMargin(new Insets(5, 50, 5, 50));
        accountPanel.add(registerButton,c);
        
        accountPanel.setBackground(Color.white);
    
        //adding action listeners
        //----------------------- sign up 
        registerButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                registerUser(e);
            }
        });
    }
    
    //adding action events
    //-------------------- signing up confirmation
    public void registerUser(ActionEvent e)
    {
          usernameRegister = inpUsername1.getText();
          passwordRegister = inpPassword1.getText();
          nameRegister = inpName.getText();
          
          if(passwordRegister == null)
          {
             JOptionPane.showMessageDialog(null, "You are missing a few information","Error", JOptionPane.ERROR_MESSAGE); 
          }
          
          else if(usernameRegister.equals(""))
          {
              JOptionPane.showMessageDialog(null, "You are missing a few information","Error", JOptionPane.ERROR_MESSAGE);
          }
          
          else if(nameRegister.equals(""))
          {
              JOptionPane.showMessageDialog(null, "You are missing a few information","Error", JOptionPane.ERROR_MESSAGE);
          }
          
          else
          {
              JOptionPane.showMessageDialog(null, "You have successfully registered " +nameRegister+ "!","Success!", JOptionPane.INFORMATION_MESSAGE);
              accountPanel.removeAll();
              accountPanel.add(new userLogin().accountPanel);
              accountPanel.updateUI();
          }
    }
    
    
}
